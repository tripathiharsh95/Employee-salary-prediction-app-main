# Employee-salary-prediction-app
A web app that predicts if an employee earns over $50K based on age, education, occupation, and work hours
